using UnityEngine;

public class PuckController
{
    private void Start()
    {

    }

    private void Update()
    {

    }
}
