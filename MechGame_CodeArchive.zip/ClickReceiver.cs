using UnityEngine;

public interface IClickReceiver
{
    void OnClick(RaycastHit hit);
}
